# to display the result a student has scored 
#(same as 5th program) using case...esac statement.
echo "the total of 3"
echo "M1 "
read m1
echo "M2"
read m2
echo "M3"
read m3
tot=$(((m1+m2+m3)/3))
if [ $tot -gt 80 ]
then
tot=1
elif [ $tot -gt 60 ]
then
tot=2
elif [ $tot -gt 35 ]
then
tot=3
else
tot=4
fi
case $tot in
"1") echo "Divison 1"
;;
"2") echo "Divison 2"
;;
"3") echo "Divison 3"
;;
"4") echo "Fail....."
;;
esac
