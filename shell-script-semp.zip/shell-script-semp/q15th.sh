#to check two file contents are same. ( Hint: use cmp or diff  command )
#!/bin/bash

file1='sample.txt'
file2='sample2.txt'

if cmp -s "$file1" "$file2"; then
    printf 'The file "%s" is the same as "%s"\n' "$file1" "$file2"
else
    printf 'The file "%s" is different from "%s"\n' "$file1" "$file2"
fi

