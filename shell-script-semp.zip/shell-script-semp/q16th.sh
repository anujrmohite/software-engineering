# to print a pyramid of numbers.
#!/bin/bash

echo "Enter num of Rows:"
read rows

for ((i=1;i<=rows;i++))
do
    for ((j=1;j<=i;j++))
    do
      printf "* "
      done
  printf "\n"
done
