#Move all duplicate files (except one)
#from a folder to a target location, etc
#• Hint:-
#• Check diff, cmp command
#• 1. find files with equal size
#• 2. compare files with equal size
#• 3. if found equal then move to
#temporary directory
mv `find ./lab/ ! -empty -type f -exec md5sum {} + | sort | uniq -w32 -dD | awk '{print $2}' | head -n -1` ./lab/transfer/