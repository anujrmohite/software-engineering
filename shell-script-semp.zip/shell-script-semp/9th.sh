echo "enter file name"
read fname
echo "Enter info"
read data
echo $data>$fname
