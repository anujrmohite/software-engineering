#to read the contents of a file 
#and display it line by line in command prompt. 
#(Hint: use read command to read the file contents.)
#!/bin/bash

filename='sample.txt'

while read line
do

echo "$line"

done < "$filename"
