echo "Enter number 1"
read n1

echo "Enter the number 2"
read n2

total=$(($n1 + $n2))

echo "Addiqtion = $total"

sub=$(($n1 - $n2))

echo "Subtraction = $sub"

div=$(($n1 / $n2))

echo "Division = $div"

mul=$(($n1 * $n2))

echo "Multiplication = $mul"




