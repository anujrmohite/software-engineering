echo "Enter the name of the dir"
read name
if [ -d $name ]
then
echo "error file already exist!!"

else
mkdir $name
echo "Folder created sucessfully"
fi
